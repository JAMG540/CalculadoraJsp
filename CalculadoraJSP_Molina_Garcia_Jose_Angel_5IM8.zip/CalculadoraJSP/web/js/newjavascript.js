function asignar (operacion)
{
    var asigna=operacion;
    var recibe=document.getElementById("oper");
    
    recibe.value=asigna;
}

